package com.edu.unab.VotaColombia.Entidad;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Candidato {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_candidato")
    private int id_candidato;
    @Column(nullable = false)
    private String nombres;
    @Column(nullable = false)
    private String apellidos;
    @Column(nullable = false)
    private int edad;
    @Column(nullable = false)
    private int sexo;
    @Column(nullable = false)
    private String partido;
    @Column(nullable = false)
    private String descripcion;
    @Column(nullable = false)
    private Blob foto;
    
    public Candidato(int id_candidato, String nombres, String apellidos, int edad, int sexo, String partido,
            String descripcion, Blob foto) {
        this.id_candidato = id_candidato;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
        this.sexo = sexo;
        this.partido = partido;
        this.descripcion = descripcion;
        this.foto = foto;
    }

    public int getId_candidato() {
        return id_candidato;
    }

    public void setId_candidato(int id_candidato) {
        this.id_candidato = id_candidato;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getSexo() {
        return sexo;
    }

    public void setSexo(int sexo) {
        this.sexo = sexo;
    }

    public String getPartido() {
        return partido;
    }

    public void setPartido(String partido) {
        this.partido = partido;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Blob getFoto() {
        return foto;
    }

    public void setFoto(Blob foto) {
        this.foto = foto;
    }

    @Override
    public String toString() {
        return "Candidato [id_candidato=" + id_candidato + ", nombres=" + nombres + ", apellidos=" + apellidos
                + ", edad=" + edad + ", sexo=" + sexo + ", partido=" + partido + ", descripcion=" + descripcion
                + ", foto=" + foto + "]";
    }
}