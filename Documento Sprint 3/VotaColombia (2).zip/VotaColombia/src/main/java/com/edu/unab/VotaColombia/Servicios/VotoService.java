package com.edu.unab.VotaColombia.Servicios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edu.unab.VotaColombia.Entidad.Voto;

@Repository
public interface VotoService extends JpaRepository<Voto, Integer>{
    Voto findByIdentificacion(int Identificacion);
}
