package com.edu.unab.VotaColombia.Controlador;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControlMain {
    @GetMapping("/gesMain")
    public String logVotantes(){
        return "/admin/main/index.html";
    }
}
