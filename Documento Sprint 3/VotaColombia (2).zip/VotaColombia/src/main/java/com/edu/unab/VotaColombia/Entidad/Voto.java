package com.edu.unab.VotaColombia.Entidad;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Voto {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id_voto;
    private int identificacion;
    @Column(nullable = false)
    private int idCandidato;
    @Column(nullable = false)
    private String fecha_hora;

    
    public Voto(int id_voto,String fecha_hora, int identificacion, int idCandidato) {
        this.id_voto = id_voto;
        this.fecha_hora = fecha_hora;
        this.identificacion = identificacion;
        this.idCandidato = idCandidato;
    }
    
   

    public String getFecha_hora() {
        return fecha_hora;
    }
    public void setFecha_hora(String fecha_hora) {
        this.fecha_hora = fecha_hora;
    }
    public int getIdentificacion() {
        return identificacion;
    }
    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }
    public int getIdCandidato() {
        return idCandidato;
    }
    public void setIdCandidato(int idCandidato) {
        this.idCandidato = idCandidato;
    }


    public int getId_voto() {
        return id_voto;
    }


    public void setId_voto(int id_voto) {
        this.id_voto = id_voto;
    }

    

}
