package com.edu.unab.VotaColombia.Controlador;




import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;




@Controller
public class ControlVotos {
    @GetMapping("/gesVotos")
    public String logVotantes(){
        return "/admin/Votos/votos.html";
    }
    
    @GetMapping("/loader")
    public String loaderV(){
        return "/admin/Votos/loader.html";
    }

   
}
