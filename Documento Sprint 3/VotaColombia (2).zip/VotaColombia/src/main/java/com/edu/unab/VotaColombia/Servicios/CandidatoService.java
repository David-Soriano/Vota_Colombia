package com.edu.unab.VotaColombia.Servicios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edu.unab.VotaColombia.Entidad.Candidato;

@Repository
public interface CandidatoService extends JpaRepository<Candidato, Integer>{
    
}
