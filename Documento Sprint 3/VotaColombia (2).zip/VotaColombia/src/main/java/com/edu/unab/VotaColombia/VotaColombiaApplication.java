package com.edu.unab.VotaColombia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotaColombiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotaColombiaApplication.class, args);
	}

}
