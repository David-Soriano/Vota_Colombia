package com.edu.unab.VotaColombia.Controlador;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.edu.unab.VotaColombia.Entidad.Votante;
import com.edu.unab.VotaColombia.Servicios.VotanteService;

@Controller
public class ControlVotantes {

	@GetMapping("/msjError")
    public String errorMsj(){
        return "/admin/Votantes/errormess.html";
    }

    @GetMapping("/gesVotantes")
    public String logVotantes(){
        return "/admin/Votantes/votantes.html";
    }

    @GetMapping("/regVotante")
    public String regVotante(){
        return "/admin/Votantes/regVotante.html";
    }

    @Autowired
    private VotanteService votanteService;
    Votante objVot = new Votante();

    @PostMapping("/Registrar")
    public String saveVotante(@Validated Votante votante){
        votanteService.save(votante);
		return "redirect:/gesVotantes";
    }
	
    @PostMapping("/validar")
	public String valida(@Validated Votante votante, Model model) {
		try {
			Optional<Votante> objVotante = votanteService.findById(votante.getIdentificacion());
			if (objVotante.isEmpty()) {
				return"/admin/Votantes/errormess";
			} else {
				objVot = objVotante.get();
				if (objVot.getIdentificacion() == votante.getIdentificacion() && objVot.getContrasena().equals(votante.getContrasena())) {
					model.addAttribute("votante", objVotante.get());
					
					return "/admin/Votos/votos";
				} else {
					return"/admin/Votantes/errormess";
				}
			}


		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return "redirect:/gesVotantes";
	}

    
}
