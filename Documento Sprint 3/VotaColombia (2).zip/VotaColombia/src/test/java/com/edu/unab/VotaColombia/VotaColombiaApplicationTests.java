package com.edu.unab.VotaColombia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotaColombiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
